from odoo import fields, models


class Todo(models.Model):
    _name = 'todo.list'
    _description = 'Todo'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    status = fields.Selection(
       [('ongoing','Ongoing'),
	('completed','Completed')],
	'STATUS')
    company_contact = fields.Many2one('res.partner', string='COMPANY/CONTACT')
    country = fields.Many2one('res.country', string='COUNTRY')
    resume = fields.Char('RESUME', required=True)
    related_project = fields.Many2one('project.project', string='PROJECT')
    related_task = fields.Many2one('project.task', string='TASK')
    create_date = fields.Date(string='CREATE')
    closed_date = fields.Date(string='CLOSED')
