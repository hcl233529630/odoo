{
    'name': 'Todo',
    'description': 'Todo Description',
    'author': 'Lafite',
    'depends': ['base','mail','project'],
    'application': True,
    'data': [
        'security/todo_security.xml',
	'security/ir.model.access.csv',
	'views/todo_menu.xml',
        'views/list_view.xml',
    ],
}
